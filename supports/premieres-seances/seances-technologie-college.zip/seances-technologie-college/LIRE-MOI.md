# Séances de technologie au collège

Une séance de 55 minutes pour chaque niveau, avec uniquement des PC.

## Utilisation immédiate

1. Extraire ce dossier ZIP.
2. Ouvrir le guide professeur dans professeur/ : déroulement de 55 minutes, script du cours, réponses orales et corrigés.
3. Commencer par 5 minutes d’accroche puis 7 minutes de cours. Faire ouvrir le PDF du niveau cours/*-cours-avant.pdf ; chacun suit sur son PC, sans vidéoprojecteur obligatoire.
4. Distribuer le fichier HTML du niveau, situé dans eleves/, pour les 25 minutes d’activité. Un double-clic l'ouvre dans un navigateur ; aucun compte ni installation n'est nécessaire.
5. Faire 10 minutes de correction puis donner cours/*-trace-apres.pdf pour 5 minutes de synthèse. Ne pas demander de recopier les schémas en entier. Terminer par 3 minutes de bilan individuel et d’enregistrement.
6. Les élèves complètent les cases et cliquent sur « Télécharger mes réponses ». Ils remettent ensuite le fichier texte par le canal habituel. Aucune réponse n'est envoyée automatiquement. Télécharger avant de fermer la page.
7. À deux sur un PC, cocher le travail en binôme, alterner le clavier et répondre chacun au bilan individuel.

Les PDF élèves peuvent être imprimés ou consultés à l’écran. Distribuer le cours AVANT, puis l’activité, puis la trace APRÈS. Le dossier professeur/ contient les corrigés et un PDF réunissant tous les cours. Les dessins sont originaux ; aucune ressource extérieure n’est nécessaire.

## Séances

- 5e : Un objet, un besoin, des solutions. Choisir un objet, identifier ses composants et justifier une amélioration.
- 4e : Allumer seulement quand c'est utile. Tester une règle avec OU, la corriger avec ET et vérifier le cas limite.
- 3e : Un portail, deux chaînes. Étudier les chaînes d'information et d'énergie d'un portail automatique.

Le navigateur conserve les réponses uniquement tant que la page reste ouverte. Les simulations ne nécessitent pas Internet. Les modèles techniques sont volontairement simplifiés.

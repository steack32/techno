# 3e - Fiche professeur

## Un portail, deux chaînes

**55 minutes ; une séance pour la semaine du 7 au 11 septembre 2026.**

**Objectif :** Distinguer les deux chaînes, associer des composants à leurs fonctions et expliquer le lien entre ordre et action.

**Prérequis :** Reconnaître un moteur et une forme d'énergie électrique ou mécanique. Ne pas supposer les sept fonctions déjà mémorisées.

**Programme :** Rattachement de contenu au programme du cycle 4 de 2020 : analyse du fonctionnement d'un objet, de ses entrées/sorties et de ses flux d'énergie et d'information. Le déploiement local du programme 2024 atteint la 4e en 2026 ; cette séance de 3e utilise le vocabulaire du programme antérieur, également présent dans le nouveau.

## Préparation

Déposer `activite-eleve.html` sur les PC ou dans un espace de distribution habituel. Le fichier peut être copié par clé USB ou dossier partagé et ouvert par double-clic. Un PC par élève ou par binôme suffit. Les documents ne demandent aucun téléchargement pendant la séance. Vérifier une fois que le navigateur autorise l’ouverture du fichier et le téléchargement des réponses. Prévoir le fichier PDF en solution de repli.

Les élèves téléchargent un fichier texte et le remettent par le canal habituel de la classe ; aucun envoi automatique ni compte n’est prévu. En binôme, alterner le clavier et demander deux billets de sortie distincts.

## Cours avant activité et trace écrite

Ouvrir le PDF `3e-cours-avant.pdf` avec les élèves pendant les sept minutes de cours. Un vidéoprojecteur est facultatif : chacun peut consulter le document sur son PC et écouter les explications. Distribuer `3e-trace-apres.pdf` à la correction. Le schéma complété se conserve sans être recopié intégralement.

[Script détaillé du cours](S01-cours.md)

## Déroulement

| Temps | Étape | Conduite de séance |
| --- | --- | --- |
| 0-5 min | Accroche | Un détecteur de présence fournit-il l’énergie qui fait briller une lampe ? |
| 5-12 min | Cours illustré | Suivre le script AVANT ; définir le vocabulaire et vérifier oralement la compréhension. |
| 12-37 min | Activité sur PC | 12-17 : lire le modèle et traiter Q1-Q2 en réponses courtes. 17-29 : construire les chaînes (Q3) et traiter Q4 ; fournir les fonctions dans l’ordre aux élèves fragiles. 29-37 : tester les quatre situations de Q5, avec changement de pilote après deux essais. Q6-Q7 sont traitées oralement en correction ; les plus rapides peuvent les rédiger. |
| 37-47 min | Correction | 37-41 : compléter le schéma et suivre l’ordre vers distribuer. 41-44 : discuter Q6 (transmettre défaillante) et Q7 (carte classée par son rôle). 44-47 : vérifier les quatre ordres, puis compléter la synthèse. Faire citer électrique en entrée et mécanique en sortie du moteur. |
| 47-52 min | Trace écrite | Distribuer la page APRÈS avec le schéma déjà complété. Ne pas demander de recopier les sept cases en cinq minutes. Faire suivre les flèches et écrire une phrase : « L’ordre arrive au bloc distribuer ; le moteur convertit l’énergie électrique en énergie mécanique. » |
| 52-55 min | Bilan individuel | Répondre au billet de sortie puis télécharger les réponses. Réserver la dernière minute à l’enregistrement ; en binôme, chacun répond dans sa case. |

## Critères de réussite

- Les trois fonctions de la chaîne d'information et les quatre fonctions de la chaîne d'énergie sont ordonnées.
- Le moteur est distingué du capteur ; la conversion électrique vers mécanique est repérée.
- L'ordre de commande est relié au module de puissance, puis à l'action sur le portail.

## Aides et points de vigilance

- Donner les sept fonctions dans l'ordre ; demander uniquement l'association des composants.
- Faire repérer dans le document les verbes indiquer, décider, transmettre un ordre, fournir l'énergie, transformer et transmettre un mouvement.
- Pour la panne : partir du constat « le moteur tourne » et suivre le mouvement vers le portail.

Le bouton est ici une entrée de commande, pas l'interrupteur de puissance du moteur. La fonction communiquer est représentée par la sortie de la carte et sa liaison vers le module de puissance. On peut aussi communiquer vers un utilisateur, mais ce second cas n'est pas étudié. La fermeture réelle d'un portail peut intégrer d'autres sécurités, une inversion et une temporisation ; elles sont hors du modèle.

## Bilan et suite

Bilan formatif, éventuellement /6 : classement des deux composants 2 points ; formes d'énergie à l'entrée et à la sortie du moteur 2 points ; ordre relié au module de puissance et à l'action 2 points.

Suite possible : Réinvestir les deux chaînes sur un autre système et réaliser un diagnostic à partir de mesures ou d'observations.

## Références

- [Programme de technologie, BO du 29 février 2024](https://www.education.gouv.fr/sites/default/files/document/Annexe%20%E2%80%94%20Programme%20de%20technologie%20du%20cycle%204-368016.pdf)
- [Lettre de rentrée STI, Nouvelle-Calédonie, février 2025](https://www.ac-noumea.nc/IMG/pdf/2025_lettre_de_rentree_sti.pdf)
- [Lettre de rentrée STI, Nouvelle-Calédonie, février 2026](https://s2i2a.ac-noumea.nc/spip.php?article112=)
- [Ressources nationales de technologie au cycle 4](https://eduscol.education.gouv.fr/5745/ressources-d-accompagnement-du-programme-de-technologie-au-cycle-4)
- [DEPP, CEDRE technologie 2024 : compétences du programme 2020](https://www.education.gouv.fr/sites/default/files/document/cedre-sciences-coll-ge-technologie-2024-518699.pdf)


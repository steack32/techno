# Séances de technologie - semaine du 7 au 11 septembre 2026

Une séance de 55 minutes pour chaque niveau, avec uniquement des PC.

## Utilisation immédiate

1. Extraire ce dossier ZIP.
2. Ouvrir le guide professeur dans professeur/ pour le déroulement et les corrigés.
3. Distribuer le fichier HTML du niveau, situé dans eleves/. Un double-clic l'ouvre dans un navigateur ; aucun compte ni installation n'est nécessaire.
4. Les élèves complètent les cases et cliquent sur « Télécharger mes réponses ». Ils remettent ensuite le fichier texte par le canal habituel. Aucune réponse n'est envoyée automatiquement. Télécharger avant de fermer la page.
5. À deux sur un PC, cocher le travail en binôme, alterner le clavier et répondre chacun au bilan individuel.

Les PDF élèves peuvent être imprimés. Ne distribuer aux élèves que leur activité ; le dossier professeur/ contient les corrigés.

## Séances

- 5e : Un objet, un besoin, des solutions. Choisir un objet, identifier ses composants et justifier une amélioration.
- 4e : Allumer seulement quand c'est utile. Tester une règle avec OU, la corriger avec ET et vérifier le cas limite.
- 3e : Un portail, deux chaînes. Étudier les chaînes d'information et d'énergie d'un portail automatique.

Le navigateur conserve les réponses uniquement tant que la page reste ouverte. Les simulations ne nécessitent pas Internet. Les modèles techniques sont volontairement simplifiés.
